package com.github.rmtmckenzie.qrmobilevision;

class NoPermissionException extends RuntimeException {
}
